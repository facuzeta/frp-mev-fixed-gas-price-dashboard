package main

import (
	b64 "encoding/base64"
	"encoding/json"
	"fmt"
	"os"

	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/std"
	"github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/types/module"

	"github.com/osmosis-labs/osmosis/v12/app/keepers"
	"github.com/osmosis-labs/osmosis/v12/app/params"
	gammtypes "github.com/osmosis-labs/osmosis/v12/x/gamm/types"
)

// esta funcion me la robe de app.go para poder incluirla aca
// y simplificar los test porque hago mas autonoma arb
func MakeEncodingConfig() params.EncodingConfig {

	encodingConfig := params.MakeEncodingConfig()
	ModuleBasics := module.NewBasicManager(keepers.AppModuleBasics...)
	std.RegisterLegacyAminoCodec(encodingConfig.Amino)
	std.RegisterInterfaces(encodingConfig.InterfaceRegistry)
	ModuleBasics.RegisterLegacyAminoCodec(encodingConfig.Amino)
	ModuleBasics.RegisterInterfaces(encodingConfig.InterfaceRegistry)

	return encodingConfig
}

func castMsgAndFees(msgs []types.Msg, feeString string) string {

	// msgs data
	string_list := []string{}
	for _, m := range msgs {
		switch msg := m.(type) {
		case *gammtypes.MsgSwapExactAmountIn:
			marshalledBytes, _ := json.Marshal(msg)
			string_list = append(string_list, string(marshalledBytes))

		case *gammtypes.MsgSwapExactAmountOut:
			marshalledBytes, _ := json.Marshal(msg)
			string_list = append(string_list, string(marshalledBytes))
		default:
		}
	}
	res := "{\"Msgs\": ["
	for i, s := range string_list {
		res += s
		// pongo una coma dsp de cada mensaje salvo que sea el ultimo
		if i < len(string_list)-1 {
			res += ","
		}
	}
	res += "]" + ", \"Fee\":" + feeString + "}"
	return res

}

func Decode(tx_base64 string) string {
	TxConfig := MakeEncodingConfig().TxConfig
	MevTxDecoder := TxConfig.TxDecoder()

	msgBytes, _ := b64.StdEncoding.DecodeString(tx_base64)

	tx, err := MevTxDecoder(msgBytes)
	if err != nil {
		fmt.Println("cant decode")
		os.Exit(1)
	}

	return castMsgAndFees(tx.GetMsgs(), getFees(tx, TxConfig))
}

func getFees(tx types.Tx, TxConfig client.TxConfig) string {
	a, err := TxConfig.WrapTxBuilder(tx)
	b := a.GetTx()

	fees := b.GetFee()

	fee := types.Coin{Denom: "uosmo", Amount: types.NewInt(0)}
	if len(fees) > 0 {
		fee = fees[0]
	}
	fee_bytes, err := json.Marshal(fee)
	if err != nil {
		fmt.Println("no pude parsear fee")
	}
	return string(fee_bytes)

}

func main() {

	tx_base64 := os.Args[1]
	fmt.Println(Decode(tx_base64))
	os.Exit(0)
}
