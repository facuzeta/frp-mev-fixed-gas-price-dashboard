# Osmosis Docs

The official documentation for Osmosis has been moved to it's own repo
<https://github.com/osmosis-labs/docs>.

Access the latest docs here: <https://docs.osmosis.zone>
