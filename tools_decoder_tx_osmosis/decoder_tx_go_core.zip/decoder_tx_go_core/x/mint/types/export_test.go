package types

var (
	ErrNilEpochProvisions      = errNilEpochProvisions
	ErrNegativeEpochProvisions = errNegativeEpochProvisions
)
