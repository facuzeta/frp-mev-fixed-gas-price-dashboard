package simulation

const (
	ExpectedEpochIdentifier = epochIdentifier
)

var (
	ExpectedDistributionProportions = distributionProportions
	ExpectedDevRewardReceivers      = weightedDevRewardReceivers
)
