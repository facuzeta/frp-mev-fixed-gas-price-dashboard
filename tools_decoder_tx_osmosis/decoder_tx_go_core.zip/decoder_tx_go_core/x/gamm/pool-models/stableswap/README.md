# Stableswap

This package implements the Solidly stableswap curve, namely a CFMM with
invariant: `xy(x^2 + y^2) = k`
