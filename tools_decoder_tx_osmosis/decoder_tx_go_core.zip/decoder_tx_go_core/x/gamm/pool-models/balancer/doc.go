/*
Package balancer implements weighted constant product AMMs, satisfying the AMM pool interface from
x/gamm/types. Please refer to the specification under /spec for further information, and the
Balancer projects documentation for more details on the mathematical equations.
*/
package balancer
