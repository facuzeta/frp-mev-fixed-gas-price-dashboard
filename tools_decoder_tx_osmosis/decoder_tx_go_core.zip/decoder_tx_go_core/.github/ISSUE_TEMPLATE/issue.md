---
name: General issue
about: A template for general issues with acceptance criteria
title: ''
assignees: ''
---
<!-- < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < ☺
v                               ✰  Thanks for creating an issue! ✰    
☺ > > > > > > > > > > > > > > > > > > > > > > > > > > > > > > > > >  -->

## Background

> This is where you can provide code examples or context (e.g. past PR's)
> e.g.
> - The following PRs contributed to...

## Suggested Design

> Here, you can put concrete steps as to what to do next
> e.g.
> - create test file in...

## Acceptance Criteria

> Goals & criteria for success
> e.g.
> - all existing and new tests should pass
