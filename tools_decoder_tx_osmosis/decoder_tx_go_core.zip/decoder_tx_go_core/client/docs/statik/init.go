package statik

// This just for fixing the error in importing empty github.com/cosmos/cosmos-sdk/client/docs/statik
